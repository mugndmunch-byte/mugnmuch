import { site } from '@/config/site'
import type { LineDescription } from '@/lib/lineDescription'
import type { Order } from '@/lib/order'
import { toWaDigits } from '@/lib/phone'
import { formatPKR } from '@/lib/utils'

/** The number shipped in site.ts before the owner fills it in. */
const PLACEHOLDER_NUMBERS = new Set(['923000000000', '923001234567'])

/**
 * True only when the WhatsApp number is a real-looking Pakistani mobile (→ 923XXXXXXXXX)
 * and not the placeholder. Orders are never sent to wa.me unless this is true.
 */
export function isWhatsappConfigured(number: string = site.contact.whatsappNumber): boolean {
  const digits = toWaDigits(number)
  return digits !== null && !PLACEHOLDER_NUMBERS.has(digits)
}

/**
 * DEV-only test number: set VITE_TEST_ORDER_WHATSAPP in .env.local (gitignored) to send
 * test orders to yourself instead of the café. Ignored in production builds.
 */
const TEST_ENV: string | undefined = import.meta.env.VITE_TEST_ORDER_WHATSAPP
export const TEST_ORDER_DIGITS: string | null = import.meta.env.DEV && TEST_ENV ? toWaDigits(TEST_ENV) : null

/** Café WhatsApp digits (923XXXXXXXXX), or null while unconfigured. In DEV, the test number wins when set. */
export function cafeWaDigits(): string | null {
  if (TEST_ORDER_DIGITS) return TEST_ORDER_DIGITS
  return isWhatsappConfigured() ? toWaDigits(site.contact.whatsappNumber) : null
}

/** Dev-only start-up warning (called once from main.tsx). */
export function warnIfWhatsappUnconfigured(): void {
  if (import.meta.env.DEV && !isWhatsappConfigured()) {
    console.warn('[Mug n Munch] site.contact.whatsappNumber is still a placeholder: WhatsApp orders will not reach anyone. Fill it in src/config/site.ts.')
  }
}

/** Build a wa.me deep link to the café's WhatsApp with a prefilled message. */
export function whatsappLink(message = ''): string {
  const base = `https://wa.me/${cafeWaDigits() ?? site.contact.whatsappNumber}`
  return message ? `${base}?text=${encodeURIComponent(message)}` : base
}

export const WHATSAPP_GREETING = `Assalam o Alaikum ${site.brandName}! I want to place an order.`

/* ---------- Order message ---------- */
export const WA_MESSAGE_LIMIT = 2000
const SAFE_LIMIT = 1900

const KIND_SUFFIX: Record<LineDescription['kind'], string> = { item: '', coffee: '', burger: ' (custom burger)', wrap: ' (custom wrap)', deal: ' (deal)' }
const TYPE_TITLE: Record<Order['orderType'], string> = { delivery: 'Order type: Delivery', takeaway: 'Order type: Takeaway' }

const stripEmoji = (s: string) => s.replace(/\p{Extended_Pictographic}️?/gu, '').replace(/\s+/g, ' ').trim()

function detailLines(order: Order): string[] {
  const d = order.details
  if (d.orderType === 'delivery') return [`Area: ${d.area}`, `Address: ${d.address}`, ...(d.landmark ? [`Landmark: ${d.landmark}`] : [])]
  return [`Pickup: ${d.pickupTime}`]
}

/**
 * Plain text only: no *bold* markers and no emoji (some phones / WhatsApp Web show the stars raw and emoji as "�").
 * level 0 = full layout; 1 = shorter indent; 2 = also no blank lines. Items / layers / fillings are NEVER dropped.
 */
function render(order: Order, level: 0 | 1 | 2): string {
  const t = order.totals
  const indent = level >= 1 ? ' ' : '   '
  const items = order.lines.flatMap((l) => {
    const d = l.description
    const head = `${l.qty}× ${stripEmoji(d.title)}${KIND_SUFFIX[d.kind]} — ${formatPKR(l.lineTotal)}`
    const details = d.details.map(stripEmoji).filter(Boolean)
    return details.length ? [head, `${indent}${details.join(', ')}`] : [head]
  })
  const money = [
    `Subtotal: ${formatPKR(t.subtotal)}`,
    ...(order.orderType === 'delivery' ? [`Delivery: ${t.deliveryFee === 0 ? 'Free' : formatPKR(t.deliveryFee)}`] : []),
    ...(t.tax > 0 ? [`Tax: ${formatPKR(t.tax)}`] : []),
    `Total: ${formatPKR(t.total)}`,
  ]
  const who = [
    `Payment: ${order.payment.label}`,
    `Name: ${order.customer.name}`,
    `Phone: ${order.customer.phone}`,
    ...(order.customer.notes ? [`Notes: ${order.customer.notes}`] : []),
  ]
  const gap = level >= 2 ? [] : ['']
  const who2 = who.map(stripEmoji)
  return [`New order ${order.number}`, site.brandName, ...gap, TYPE_TITLE[order.orderType], ...detailLines(order).map(stripEmoji), ...gap, 'Items:', ...items, ...gap, ...money, ...gap, ...who2].join('\n')
}

/** Plain-text order for WhatsApp (no markdown, no emoji). Compacts the layout only if it would get too long. */
export function buildWhatsAppOrderMessage(order: Order): string {
  let msg = render(order, 0)
  if (msg.length > SAFE_LIMIT) msg = render(order, 1)
  if (msg.length > SAFE_LIMIT) msg = render(order, 2)
  return msg
}

/** wa.me link with the order prefilled, or null while the café number is a placeholder (never open wa.me then). */
export function getWhatsAppOrderUrl(order: Order, digits: string | null = cafeWaDigits()): string | null {
  return digits ? `https://wa.me/${digits}?text=${encodeURIComponent(buildWhatsAppOrderMessage(order))}` : null
}

/** "Hi, about order MM-…" link for the success page. */
export function whatsappAboutOrderLink(number: string): string | null {
  const digits = cafeWaDigits()
  return digits ? `https://wa.me/${digits}?text=${encodeURIComponent(`Hi ${site.brandName}, about order ${number}…`)}` : null
}
