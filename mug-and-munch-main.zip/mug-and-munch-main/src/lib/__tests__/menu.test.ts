import { describe, expect, it } from 'vitest'
import { COFFEE_DRINKS } from '@/data/coffeeBuilder'
import { deals, getBestValueDeal, getDealOriginalPrice, getDealSavings, getDealSavingsPercent } from '@/data/deals'
import { getFeatured, getItemById, isPriced, menu } from '@/data/menu'
import { ROULETTE_ITEMS, VIBES } from '@/data/toys'
import { describeLine } from '@/lib/lineDescription'
import { priceLine, toCartInput } from '@/lib/itemOptions'
import { getUpsells } from '@/lib/recommendations'
import { buildLineId } from '@/store/cart'
import { pricedItem, toLine } from './fixtures'

const real = menu.filter((i) => !i.id.startsWith('test-'))

describe('menu data (owner list)', () => {
  it('unique slugs; prices are positive whole PKR or null ("Price coming soon")', () => {
    expect(new Set(real.map((i) => i.slug)).size).toBe(real.length)
    for (const i of real) expect(i.price === null || (Number.isInteger(i.price) && i.price > 0)).toBe(true)
  })

  it('every id referenced by toys, coffee maker and picks exists in the menu', () => {
    const ids = [...VIBES.flatMap((v) => v.picks), ...ROULETTE_ITEMS, ...COFFEE_DRINKS]
    for (const id of ids) expect(getItemById(id), id).toBeDefined()
    expect(getFeatured().length).toBeGreaterThan(0)
  })

  it('coffee maker only offers items with a price (it configures real menu coffees)', () => {
    for (const id of COFFEE_DRINKS) expect(isPriced(getItemById(id)!), id).toBe(true)
  })
})

describe('unpriced items', () => {
  it('a cart line for an item without a price is unavailable (never sent at a made-up price)', () => {
    const latte = pricedItem('spanish-latte')
    const line = toLine(toCartInput(latte))
    const unpriced = real.find((i) => !isPriced(i))!
    expect(priceLine({ ...line, itemId: unpriced.id, category: unpriced.category, options: {} })).toEqual({ available: false })
  })

  it('upsells never suggest an item without a price', () => {
    const burgerLine = { ...toLine(toCartInput(pricedItem('test-smash'))), category: 'burger' as const }
    for (const pick of getUpsells([burgerLine], 5)) expect(isPriced(pick)).toBe(true)
  })
})

describe('flavoured lattes: Hot / Cold / Blended', () => {
  it('same price for every temp; the line always states the temp (the barista needs it)', () => {
    const latte = pricedItem('spanish-latte')
    const hot = toCartInput(latte, { temp: 'hot', extras: [] })
    const blended = toCartInput(latte, { temp: 'blended', extras: [] })
    expect(hot.unitPrice).toBe(latte.price)
    expect(blended.unitPrice).toBe(latte.price)
    expect(describeLine(toLine(hot)).details).toEqual(['Hot'])
    expect(describeLine(toLine(blended)).details).toEqual(['Blended'])
    expect(buildLineId(hot.itemId, hot.options)).not.toBe(buildLineId(blended.itemId, blended.options))
    expect(priceLine(toLine(blended))).toEqual({ available: true, unitPrice: latte.price })
  })
})

describe('craft makers in play / off mode (site.craftMakers)', () => {
  it('custom burger / wrap lines become unavailable (removed from saved carts, never sent)', async () => {
    const { site } = await import('@/config/site')
    const { bigBurger, fullWrap } = await import('./fixtures')
    const makers = site.craftMakers as Record<'burger' | 'wrap', 'order' | 'play' | 'off'>
    expect(priceLine(toLine(bigBurger())).available).toBe(true)
    makers.burger = 'play' // playable, ordering coming soon
    makers.wrap = 'off'
    try {
      expect(priceLine(toLine(bigBurger()))).toEqual({ available: false })
      expect(priceLine(toLine(fullWrap()))).toEqual({ available: false })
    } finally {
      makers.burger = 'order'
      makers.wrap = 'order'
    }
  })
})

describe('deals (proposed combos)', () => {
  const real = deals.filter((d) => !d.id.startsWith('test-'))

  it('every deal item is on the menu, prices are whole PKR, ids unique', () => {
    expect(new Set(real.map((d) => d.id)).size).toBe(real.length)
    for (const d of real) {
      expect(Number.isInteger(d.price) && d.price > 0, d.id).toBe(true)
      for (const l of d.items) expect(getItemById(l.itemId), `${d.id}: ${l.itemId}`).toBeDefined()
    }
  })

  it('owner rule: every real deal uses only priced items and genuinely saves money (so the tag is honest)', () => {
    for (const d of real) {
      expect(getDealOriginalPrice(d), d.id).not.toBeNull()
      expect(getDealSavings(d), d.id).toBeGreaterThan(0)
      expect(getDealSavingsPercent(d), d.id).toBeGreaterThan(0)
      expect(priceLine({ itemId: d.id, category: 'deal', options: {} })).toEqual({ available: true, unitPrice: d.price })
    }
    expect(getBestValueDeal()).toBeDefined()
  })

  it('a deal with an unpriced item shows NO invented savings', () => {
    const fake = { ...real[0]!, items: [{ itemId: 'munch-smash', qty: 1 }] }
    expect(getDealOriginalPrice(fake)).toBeNull()
    expect(getDealSavings(fake)).toBe(0)
    expect(getDealSavingsPercent(fake)).toBe(0)
  })

  it('savings are real when every item has a menu price (Matcha Duo)', () => {
    const duo = deals.find((d) => d.id === 'matcha-duo')!
    const sum = duo.items.reduce((s, l) => s + (getItemById(l.itemId)!.price as number) * l.qty, 0)
    expect(getDealOriginalPrice(duo)).toBe(sum)
    expect(getDealSavings(duo)).toBe(sum - duo.price)
  })
})
