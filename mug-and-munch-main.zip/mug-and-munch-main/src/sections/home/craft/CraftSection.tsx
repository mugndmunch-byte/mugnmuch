import { lazy, Suspense, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { useLocation } from 'react-router'
import { useLenis } from 'lenis/react'
import { site } from '@/config/site'
import { useReducedMotion } from '@/hooks/useReducedMotion'
import { track } from '@/lib/events'
import { gsap, refreshScrollTriggersSoon, ScrollTrigger } from '@/lib/gsap'
import { EASE } from '@/lib/motion-presets'
import { cn } from '@/lib/utils'
import { CraftSwitch, type CraftSwitchTab, type CraftTab } from './CraftSwitch'
import { MakerLoading } from './MakerLoading'
import { BURGER_PRICES_CONFIRMED } from '@/data/builder'
import { WRAP_PRICES_CONFIRMED } from '@/data/wrapBuilder'
import { BuilderModeContext, type BuilderMode } from '@/components/builder/builderMode'

// Each maker loads only when its tab is first opened (disabled makers never load).
const BurgerMaker = lazy(() => import('./BurgerMaker').then((m) => ({ default: m.BurgerMaker })))
const CoffeeMaker = lazy(() => import('./CoffeeMaker').then((m) => ({ default: m.CoffeeMaker })))
const WrapMaker = lazy(() => import('./WrapMaker').then((m) => ({ default: m.WrapMaker })))

const TABS: (CraftSwitchTab & { word: string; wordClass: string; note: string; cta: string; glow: string })[] = [
  { id: 'coffee', label: 'Coffee', emoji: '☕', activeBg: 'bg-caramel', activeText: 'text-espresso', word: 'coffee', wordClass: 'text-caramel', note: 'study grind fuel ☕', cta: 'Add my coffee', glow: 'bg-caramel' },
  { id: 'burger', label: 'Burger', emoji: '🍔', activeBg: 'bg-chili', activeText: 'text-espresso', word: 'burger', wordClass: 'text-chili', note: 'garma garam, fresh off the grill 🔥', cta: 'Add my burger', glow: 'bg-chili' },
  { id: 'wrap', label: 'Wrap', emoji: '🌯', activeBg: 'bg-pickle', activeText: 'text-espresso', word: 'wrap', wordClass: 'text-pickle', note: 'wrapped fresh, eaten faster 🌯', cta: 'Add my wrap', glow: 'bg-pickle' },
]
/** Makers not switched 'off' (site.craftMakers); coffee configures real menu coffees. */
const ENABLED = TABS.filter((t) => site.craftMakers[t.id] !== 'off')
/** Per maker: can its creation be ordered, and are its prices real? (coffee = real menu prices) */
const MODE: Record<CraftTab, BuilderMode> = {
  coffee: { ordering: site.craftMakers.coffee === 'order', showPrices: true },
  burger: { ordering: site.craftMakers.burger === 'order', showPrices: BURGER_PRICES_CONFIRMED },
  wrap: { ordering: site.craftMakers.wrap === 'order', showPrices: WRAP_PRICES_CONFIRMED },
}
// Opens on Burger (as originally built) when it's shown, else the first shown maker.
const FIRST: CraftTab = ENABLED.find((t) => t.id === 'burger')?.id ?? ENABLED[0]?.id ?? 'coffee'
const isOn = (t: CraftTab) => ENABLED.some((e) => e.id === t)
export const CRAFT_ID = 'craft'
/** #craft-<tab> → that tab; a disabled maker's link falls back to the first enabled one. */
const tabFromHash = (hash: string): CraftTab | null => {
  const m = /^#craft-(coffee|burger|wrap)$/.exec(hash)
  if (!m) return null
  const t = m[1] as CraftTab
  return isOn(t) ? t : FIRST
}

/** ONE "Craft your own" section: the shown makers (site.craftMakers) behind a switch; no switch when only one. State is kept per tab.
 *  Each maker gets its BuilderMode (play = "Add to cart · coming soon", hidden placeholder prices). */
export function CraftSection() {
  const location = useLocation()
  const lenis = useLenis()
  const reduced = useReducedMotion()
  const [tab, setTab] = useState<CraftTab>(() => tabFromHash(window.location.hash) ?? FIRST)
  const [mounted, setMounted] = useState<Record<CraftTab, boolean>>(() => ({ coffee: tab === 'coffee', burger: tab === 'burger', wrap: tab === 'wrap' }))
  const root = useRef<HTMLElement>(null)
  const switching = useRef(false)
  const firstRender = useRef(true)
  const meta = ENABLED.find((t) => t.id === tab) ?? ENABLED[0] ?? TABS[0]!

  useEffect(() => refreshScrollTriggersSoon(300), [])

  // Deep links: #craft-coffee | #craft-burger | #craft-wrap → open that tab (adjusted during render) …
  // Keyed on location.key so a repeat link to the same hash (e.g. Edit from the drawer) still re-opens.
  const [seenKey, setSeenKey] = useState(location.key)
  if (location.key !== seenKey) {
    setSeenKey(location.key)
    const target = tabFromHash(location.hash)
    if (target) {
      setTab(target)
      setMounted((m) => ({ ...m, [target]: true }))
    }
  }

  // … and scroll the section into view.
  // ScrollTrigger refreshes after load (pin spacing above us changes our position), so re-aim after each
  // refresh for a short window, then stop.
  useEffect(() => {
    if (!tabFromHash(location.hash)) return
    const go = (immediate: boolean) => {
      const el = root.current
      if (!el) return
      if (lenis) lenis.scrollTo(el, { offset: -8, duration: 1.1, immediate: immediate || reduced })
      else el.scrollIntoView({ behavior: immediate || reduced ? 'auto' : 'smooth' })
    }
    const onRefresh = () => go(true)
    // Wait for the cart drawer (Edit / Tweak) to release its scroll lock.
    const first = window.setTimeout(() => go(false), 380)
    ScrollTrigger.addEventListener('refresh', onRefresh)
    const stop = window.setTimeout(() => ScrollTrigger.removeEventListener('refresh', onRefresh), 2500)
    return () => {
      window.clearTimeout(first)
      window.clearTimeout(stop)
      ScrollTrigger.removeEventListener('refresh', onRefresh)
    }
  }, [location.key, location.hash, lenis, reduced])

  const change = (next: CraftTab) => {
    if (next === tab || switching.current || !isOn(next)) return
    track('craft_tab_switch', { tab: next })
    setMounted((m) => ({ ...m, [next]: true }))
    window.history.replaceState(window.history.state, '', `#craft-${next}`)
    const el = root.current
    const out = el?.querySelector(`[data-maker="${tab}"] [data-creation]`)
    if (reduced || !el || !out) return setTab(next)
    switching.current = true
    gsap
      .timeline({
        onComplete: () => {
          gsap.set(out, { clearProps: 'x,opacity' })
          switching.current = false
          setTab(next)
        },
      })
      .to(out, { x: -90, opacity: 0, duration: 0.22, ease: 'power2.in' }, 0)
      .to(el.querySelector('[data-word]'), { yPercent: -110, duration: 0.22, ease: 'power2.in' }, 0)
  }

  // Incoming creation drops onto the plate; tiles + word slide/fade in.
  useLayoutEffect(() => {
    if (firstRender.current) {
      firstRender.current = false
      return
    }
    const el = root.current
    if (!el || reduced) return
    gsap.fromTo(el.querySelector('[data-word]'), { yPercent: 110 }, { yPercent: 0, duration: 0.4, ease: EASE.out })
    const creation = el.querySelector(`[data-maker="${tab}"] [data-creation]`)
    if (creation) gsap.fromTo(creation, { y: -140, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, ease: EASE.bouncy })
    const controls = el.querySelector(`[data-maker="${tab}"] [data-controls]`)
    if (controls) gsap.fromTo(controls, { opacity: 0 }, { opacity: 1, duration: 0.35 })
    refreshScrollTriggersSoon(400)
  }, [tab, reduced])

  return (
    <section ref={root} id={CRAFT_ID} aria-labelledby="craft-title" className="grain relative overflow-hidden bg-espresso px-4 py-16 text-oat sm:px-6 md:py-24">
      {ENABLED.map((t) => (
        <span key={t.id} aria-hidden="true" className={cn('absolute top-1/3 left-1/4 -z-10 size-[28rem] rounded-full blur-3xl transition-opacity duration-500', t.glow, t.id === tab ? 'opacity-25' : 'opacity-0')} />
      ))}

      <div className="mx-auto max-w-6xl">
        <h2 id="craft-title" className="text-display font-extrabold text-oat">
          Craft your{' '}
          <span className="inline-block overflow-hidden pb-[0.08em] align-bottom">
            <span data-word className={cn('inline-block', meta.wordClass)}>
              {meta.word}
            </span>
          </span>
        </h2>
        <div className="mt-1 h-9">
          <AnimatePresence mode="wait" initial={false}>
            <motion.p key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="-rotate-1 font-hand text-2xl text-cheese sm:text-3xl">
              {meta.note}
            </motion.p>
          </AnimatePresence>
        </div>

        {/* grid-cols-1 = minmax(0,1fr): stops wide scroll trays from stretching the mobile column */}
        <div className="mt-6 grid grid-cols-1 gap-x-10 gap-y-5 [grid-template-areas:'stage'_'switch'_'controls'] md:grid-cols-2 md:items-center md:[grid-template-areas:'switch_switch'_'stage_controls']">
          {ENABLED.length > 1 && (
            <div className="[grid-area:switch]">
              <CraftSwitch tabs={ENABLED} active={tab} onChange={change} />
            </div>
          )}
          {isOn('burger') && mounted.burger && (
            <Suspense fallback={<MakerLoading show={tab === 'burger'} />}>
              <BuilderModeContext.Provider value={MODE.burger}>
                <BurgerMaker active={tab === 'burger'} ctaLabel={TABS[1]!.cta} />
              </BuilderModeContext.Provider>
            </Suspense>
          )}
          {isOn('coffee') && mounted.coffee && (
            <Suspense fallback={<MakerLoading show={tab === 'coffee'} />}>
              <BuilderModeContext.Provider value={MODE.coffee}>
                <CoffeeMaker active={tab === 'coffee'} ctaLabel={TABS[0]!.cta} />
              </BuilderModeContext.Provider>
            </Suspense>
          )}
          {isOn('wrap') && mounted.wrap && (
            <Suspense fallback={<MakerLoading show={tab === 'wrap'} />}>
              <BuilderModeContext.Provider value={MODE.wrap}>
                <WrapMaker active={tab === 'wrap'} ctaLabel={TABS[2]!.cta} />
              </BuilderModeContext.Provider>
            </Suspense>
          )}
        </div>
      </div>
    </section>
  )
}
